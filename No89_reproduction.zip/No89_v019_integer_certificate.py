from math import comb
from functools import lru_cache
@lru_cache(None)
def parts(s,lo=1):
 if s==0:return [()]
 return [(a,)+p for a in range(lo,s+1) for p in parts(s-a,a)]
@lru_cache(None)
def charge_cap(S,s,D):
 out=0
 for j in range(1,min(s-2,D-1)+1):
  p=min(s,S-(j-1)*(j+2)//2)
  if p>=j+2:out=max(out,sum(min(j,i) for i in range(1,p-1)))
 return out
def run(k):
 M=k*k//8;d=M+3
 allmin=[]
 states=0
 comparisons=0
 for s in range(k+1):
  mins={0:0}
  for p in parts(s):
   if not p:continue
   c=len(p)
   Hc=comb(s,2)-sum(comb(x,2) for x in p)
   Hmax=sum(comb(x-1,2) for x in p)
   for Hi in range(Hmax+1):
    H=Hc+Hi
    if H>2*k+comb(s,2)+comb(k-s,2)-(comb(k+1,2)-k*k//4+1):continue
    ds=[max(v for v in range(x) if comb(x,2)-(v+3*(x-v-1)+comb(x-v-1,2))<=Hi and comb(v,2)<=Hi) for x in p]
    D=max(ds)
    B=sum(v+2 for v in ds)
    K=B+(2*D+1>B)
    # if all components connected, each needs a P adjacency so S <= (B+1)*s-c
    for S in range((B+1)*s-c+1):
     delta=S+H
     if delta==0:continue
     states+=1
     C=min(Hi,comb(S,2),sum(x*max(x-2,0) for x in p),charge_cap(S,s,D))
     loss2=2*(d*delta-(2*delta+4)*delta)
     loss1=2*((d-K-1)*S+(d-min(2*s,B+D+1))*Hc+(d-max(1,D))*Hi)-(2*K+2-D)*C if D>=2 else 2*((d-K-1)*S+(d-min(2*s,B+D+1))*Hc+(d-max(1,D))*Hi)
     loss3=2*(d*delta-delta-(S+C)*(S+C+1)-(2*(S+C)+3)*H)
     loss=max(loss1,loss2,loss3)
     if delta==1:loss=max(loss,2*(d-3)) # U+J+1 <=3 per delta1 (cross not used)
     mins[delta]=min(mins.get(delta,10**9),loss)
  allmin.append(mins)
  #print(s, min((v,t) for t,v in mins.items() if t>=2) if s else None)
 bad=[]
 minmargin=None
 for L in range((k+1)//2,k+1):
  R=k-L
  for D1,v1 in allmin[L].items():
   for D2,v2 in allmin[R].items():
    if D1+D2<2:continue
    comparisons+=1
    margin=v1+v2-2*M
    minmargin=margin if minmargin is None else min(minmargin,margin)
    if v1+v2<=2*M:bad.append((v1+v2,L,D1,D2))
 print(f"k={k} d={d} relaxed_states={states} group_pairs={comparisons} min_twice_margin={minmargin} unresolved={len(bad)}",flush=True)
 if bad: print(" examples (twice loss,L,deltaL,deltaR):",sorted(bad)[:10],flush=True)
 return not bad
def localization(k):
 m=comb(k+1,2)-k*k//4+1-2*k
 d=k*k//8+3
 c=max(c for c in range(1,k+1) if comb(k-c+1,2)>=m)
 D=max(D for D in range(k) if any(D+3*(s-D-1)+comb(s-D-1,2)+comb(k-s,2)>=m for s in range(D+1,k+1)))
 assert d>k+c
 if d<=2*(D+1):
  assert k==11 and d==2*(D+1)
  rmin=m+2*k
  assert max(D+3*(s-D-1)+comb(s-D-1,2)+comb(k-s,2)+2*(k-s) for s in range(D+1,k+1))<rmin
 print(f"localization k={k} d={d} Bmax={k+c} Dmax={D} PASS",flush=True)
if __name__=='__main__':
 for k in range(11,19):
  localization(k)
  assert run(k)
 print('PASS k=11..18; integer relaxation, conditional on proof lemmas')
 print('Diagnostic k=10: not certified; localization not asserted')
 assert not run(10)

