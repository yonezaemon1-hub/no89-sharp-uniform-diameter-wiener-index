from pathlib import Path
import hashlib, subprocess, sys, os
from check import parse, full
base=Path(__file__).resolve().parent
source=base/'No89_v023_layered.cpp'; exe=base/('no89_verify.exe' if os.name=='nt' else 'no89_verify')
logs=base/'rerun_logs';logs.mkdir(exist_ok=True)
subprocess.run(['g++','-O3','-std=c++17',str(source),'-o',str(exe)],check=True)
sha=hashlib.sha256(source.read_bytes()).hexdigest(); esha=hashlib.sha256(exe.read_bytes()).hexdigest()
print('SOURCE SHA256',sha,'EXECUTABLE SHA256',esha,flush=True)
for k in range(4,11):
 for d in range(k*k//8+3,2*k+1):
  p=logs/f'k{k}_d{d}.log'; header=f'SOURCE_SHA256={sha}\nEXECUTABLE_SHA256={esha}\n'
  if p.exists():
   try:
    t=p.read_text(); assert t.startswith(header) and '\nEXIT=0\n' in t
    g=parse(p);assert set(g)=={(k,d,-1)};full(k,d,g[k,d,-1]);print('SKIP completed',k,d,flush=True);continue
   except (AssertionError,ValueError,OSError):pass
  print('START',k,d,flush=True)
  result=subprocess.run([str(exe),str(k),str(d)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  tmp=p.with_suffix('.tmp');tmp.write_text(header+result.stdout+f'\nEXIT={result.returncode}\n',encoding='utf-8');tmp.replace(p)
  if result.returncode:raise SystemExit(f'FAIL exit {result.returncode} {k=} {d=}')
  g=parse(p);assert set(g)=={(k,d,-1)};full(k,d,g[k,d,-1]);print('PASS',k,d,flush=True)
subprocess.run([sys.executable,str(base/'check.py'),str(logs)],check=True)
