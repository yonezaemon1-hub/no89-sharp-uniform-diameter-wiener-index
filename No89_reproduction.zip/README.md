# No.89 — reproducibility package

Use Python 3.10+ and g++ supporting C++17. No third-party Python packages are required. Extract the ZIP, then run from its root:

```text
python check.py
python check.py windows_logs
python No89_v019_integer_certificate.py
python run_all.py
```

The first two commands check shipped log coverage, exact formula, equality markers and seven lower witnesses. The third enumerates the finite integer relaxation for k=11..18 and an intentionally unsuccessful k=10 diagnostic. The last builds the unchanged C++ source and executes all 39 instances, producing `rerun_logs/`. It may skip a completed valid log only if its source and executable hashes match. Do not run Python with optimization flags that disable assertions. The proof is in the accompanying manuscript; the log checker does not establish mathematical pruning validity.

For provenance and limitations see PROVENANCE.md. Independent AI audit: CONDITIONAL PASS. NOT HUMAN PEER REVIEWED / NOVELTY INCONCLUSIVE / REFERENCES PARTIAL. All rights reserved.
