from pathlib import Path
import re
from collections import deque
BASE=Path(__file__).resolve().parent
ROW=r'r=(\d+) best=(-?\d+) pred=(\d+) ties=(\d+) noncanonical=(\d+)'
def pred(k,d,r):
 A=k*(k+1)//2; h=A-r; R=next(j for j in range(k//2+1) if j*(k-j)>=h); q=R*(k-R)-h
 return d*(d+1)*(d+2)//6+k*d*(d+1)//2+h*d+r-q*R

def parse(p):
 groups={}; key=None
 for l in p.read_text().splitlines():
  m=re.match(r'^k=(\d+) d=(\d+)(?: zfilter=(-?\d+))? options=',l)
  if m:
   k,d=map(int,m.groups()[:2]); z=int(m[3] or -1); key=(k,d,z); assert key not in groups; groups[key]=[]
  m=re.fullmatch(ROW,l)
  if m: assert key is not None; groups[key].append(tuple(map(int,m.groups())))
 for (k,d,z),rows in groups.items():
  A=k*(k+1)//2; C=A-k*k//4
  assert [a[0] for a in rows]==list(range(C+1,A))
  for r,b,p,t,bad in rows:assert p==pred(k,d,r) and b<=p and bad==0 and ((b==-1 and t==0) or (b==p and t>0))
 return groups

def full(k,d,rows):
 assert all(b==p and t>0 and bad==0 for r,b,p,t,bad in rows)

def merge_shards(k,d,groups):
 assert set(groups)=={(k,d,z) for z in range(k+1)}
 for rowset in zip(*(groups[(k,d,z)] for z in range(k+1))):
  assert len({a[0] for a in rowset})==1 and len({a[2] for a in rowset})==1
  r=rowset[0][0]; assert max(a[1] for a in rowset)==pred(k,d,r)
  assert sum(a[3] for a in rowset)>0 and sum(a[4] for a in rowset)==0

def witness(k):
 M=k*k//8;d=M+2;j=max(range(1,k//2+1),key=lambda x:x*(k-2*x));h=(j-1)*(k-j+1)+1;r=k*(k+1)//2-h;L=k-j;R=j;q=L*R-h
 def construct(L,R,q,remove=False):
  G=[set() for _ in range(d+1+k)]
  def add(a,b): G[a].add(b);G[b].add(a)
  for i in range(d):add(i,i+1)
  left=list(range(d+1,d+1+L));right=list(range(d+1+L,d+1+k))
  for a in (left,right):
   for i,x in enumerate(a):
    for y in a[i+1:]:add(x,y)
  for x in left:add(x,0);add(x,1)
  for x in right:add(x,d);add(x,d-1)
  for x in left[:q]:add(x,2)
  if remove:G[left[0]].remove(0);G[0].remove(left[0])
  return G
 def metrics(G):
  es=[]; W=0
  for x in range(len(G)):
   ds={x:0};Q=deque([x])
   while Q:
    u=Q.popleft()
    for v in G[u]:
     if v not in ds:ds[v]=ds[u]+1;Q.append(v)
   assert len(ds)==len(G);es.append(max(ds.values()));W+=sum(ds.values())
  return sum(map(len,G))//2,max(es),W//2,es.count(d)
 a=metrics(construct(L,R,q));b=metrics(construct(L+1,R-1,0,True))
 assert a[:3]==b[:3]==(d+k+r,d,pred(k,d,r));assert a[3]!=b[3]
 print(f'lower witness k={k} d={d} r={r} W={a[2]} ecc_d={a[3]},{b[3]} PASS')

if __name__=='__main__':
 import sys
 root=Path(sys.argv[1]) if len(sys.argv)>1 else BASE/'logs'
 total=0; counts={}
 for k in range(4,11):
  nrows=0
  for d in range(k*k//8+3,2*k+1):
   p=root/f'k{k}_d{d}.log'; s=p.read_text(encoding='utf-8'); assert re.search(r'^EXIT=0$',s,re.M),p
   g=parse(p); assert set(g)=={(k,d,-1)},p
   full(k,d,g[k,d,-1]);nrows+=len(g[k,d,-1])
   for key in ('masks','nodes','pruned','rowcuts','exact_tests','valid'):
    counts[key]=counts.get(key,0)+int(re.search(r'\b'+key+r'=(\d+)',s).group(1))
  total+=nrows;print(f'k={k} complete rows={nrows} PASS');witness(k)
 assert total==499
 print('TOTAL',total,counts)
 print('FINITE CERTIFICATE PASS; conditional on inherited proofs; not an independent audit')
