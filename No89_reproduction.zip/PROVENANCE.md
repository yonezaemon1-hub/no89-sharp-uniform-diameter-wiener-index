# Reproduction provenance

Copyright 2026 Ryutaro Yonezu. All rights reserved.

Final source SHA256: `76aa85d01a288de8849cd770286f505e7cbaa5e01c776fe14e8dfc71368ac544`. All four executable source files are byte-identical to the audited v0.23 candidate. Original Linux logs are unchanged, and their missing source hash headers are not retroactively fabricated. The Windows logs contain source and executable hash headers, and the source hash matches the archived source. The compiler and executable themselves are not included; their hashes are reported build metadata. The auditor reported a separate matching run.

Editorial recheck: both 39-instance log sets passed check.py (499 rows, seven witnesses per run); the integer certificate was executed again. This is not a new execution of the full C++ enumeration, a sanitizer rerun, or an independent audit of the revised text.

The independent six-stage AI audit verdict was CONDITIONAL PASS. The analytic and integer portions were assessed PASS, but implementation evidence for k=4..10 remains conditional. Some differential, full-enumeration and heuristic tests were stopped before completion; ASan/UBSan was not run for k=10 (33/39 instances covered). No mathematical FAIL was reported. The log checker does not prove pruning safety. The k=10 integer diagnostic intentionally reports 44 unresolved relaxed states; it is not a counterexample, and is not used in the proof.

NOT HUMAN PEER REVIEWED / NOVELTY INCONCLUSIVE / REFERENCES PARTIAL.
