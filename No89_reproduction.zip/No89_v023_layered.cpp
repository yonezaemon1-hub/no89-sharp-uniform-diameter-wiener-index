#include <bits/stdc++.h>
using namespace std; using U=uint64_t;
int k,d,n,A,M,C; vector<U> opts; vector<int> chosen; vector<pair<int,int>> ep; long long candidates,valid,masks,pruned,nodes; vector<long long> best, ties,badties; vector<vector<U>> ex; 
long long B(int x){return 1LL*x*(x-1)/2;} long long F(){return 1LL*d*(d+1)*(d+2)/6+k*B(d+1);} long long formula(int r){int h=A-r,R=0;while(R*(k-R)<h)++R;int q=R*(k-R)-h;return F()+1LL*h*d+r-q*R;}
bool shape(vector<U>& adj,int r){int h=A-r,R=0;while(R*(k-R)<h)++R;int L=k-R,q=R*L-h; for(int flip=0;flip<2;flip++){int nl=0,nr=0,nq=0;bool ok=true;vector<int> side(k);for(int i=0;i<k;i++){U mask=adj[d+1+i]&((1ULL<<(d+1))-1);if(flip){U x=0;for(int j=0;j<=d;j++)if(mask>>j&1)x|=1ULL<<(d-j);mask=x;}if(mask==3||mask==7){side[i]=0;nl++;nq+=(mask==7);}else if(mask==(3ULL<<(d-1))){side[i]=1;nr++;}else {ok=false;break;}}if(!ok||nl!=L||nr!=R||nq!=q)continue;for(auto [i,j]:ep)if(bool(adj[d+1+i]>>(d+1+j)&1)!=(side[i]==side[j]))ok=false;if(ok)return true;}return false;}

// Each cap is an upper bound on the corresponding distance in any valid completion.
bool dist(vector<U>& adj,int D[64][64],long long& w,bool exact){
 U full=(1ULL<<n)-1;w=1LL*d*(d+1)*(d+2)/6;
 for(int i=0;i<=d;i++)for(int j=0;j<=d;j++)D[i][j]=abs(i-j);
 for(int i=d+1;i<n;i++){U seen=1ULL<<i,fr=seen;D[i][i]=0;
 for(int dep=1;dep<=d;dep++){U nxt=0;while(fr){int j=__builtin_ctzll(fr);fr&=fr-1;nxt|=adj[j];}fr=nxt&~seen;if(!fr)break;seen|=fr;U tmp=fr;while(tmp){int j=__builtin_ctzll(tmp);tmp&=tmp-1;D[i][j]=D[j][i]=dep;if(j<=d||j>i)w+=dep;}if(seen==full)break;}
 U tmp=full&~seen;if(exact&&tmp)return false;while(tmp){int j=__builtin_ctzll(tmp);tmp&=tmp-1;D[i][j]=D[j][i]=d;if(j<=d||j>i)w+=d;}
 int minleft=d+1;for(int j=0;j<=d;j++){if(minleft+D[i][j]<j)return false;minleft=min(minleft,D[i][j]+j);}
 }return true;
}
bool bound(int cur,U rem,int D[64][64],long long w){
 int hist[64]={};while(rem){int z=__builtin_ctzll(rem);rem&=rem-1;auto [i,j]=ep[z];hist[D[d+1+i][d+1+j]-1]++;}
 int t=0;long long cost=0;for(int v=0;v<d;v++)for(int i=0;i<hist[v];i++){if(cur+t>C&&cur+t<A&&w-cost>=formula(cur+t))return true;cost+=v;t++;}return cur+t>C&&cur+t<A&&w-cost>=formula(cur+t);
}
// Additivity via per-vertex incident-degree averaging. Scale 2520 is divisible by 1..10.
bool pathbound(int cur,U rem,int D[64][64],long long w){
 constexpr int SCALE=2520;int deg[16]={},vals[64],m=0;U t=rem;
 while(t){int z=__builtin_ctzll(t);t&=t-1;auto [i,j]=ep[z];deg[i]++;deg[j]++;}
 t=rem;while(t){int z=__builtin_ctzll(t);t&=t-1;auto [i,j]=ep[z];int a=d+1+i,b=d+1+j,sa=0,sb=0;for(int p=0;p<=d;p++){int dif=D[a][p]-D[b][p];sa+=max(0,dif-1);sb+=max(0,-dif-1);}vals[m++]=(D[a][b]-1)*SCALE+sa*(SCALE/deg[i])+sb*(SCALE/deg[j]);}
 sort(vals,vals+m);long long upper=w*SCALE;for(int t=0;t<=m;t++){if(cur+t>C&&cur+t<A&&upper>=formula(cur+t)*SCALE)return true;if(t<m)upper-=vals[t];}return false;
}
U rowmask[16]; int edgeindex[16][16]; long long target; long long rowcuts=0; long long empty_upper[16],empty_sum[16];
vector<vector<int>> profiles[16][64]; const vector<vector<int>>* active_profiles=nullptr;
long long profilemax=0;
void make_profiles(){
 for(int z=0;z<k;z++){
  for(int mask=0;mask<(1<<max(0,z-1));mask++){
   vector<int> level={k-z}, seq; if(z){int count=1;for(int i=0;i<z-1;i++){if(mask>>i&1){level.push_back(count);count=1;}else count++;}level.push_back(count);}
   int cap=0;for(int i=0;i<(int)level.size();i++){cap+=B(level[i]);if(i)cap+=level[i-1]*level[i];if(i)for(int j=0;j<level[i];j++)seq.push_back(i);}
   for(int m=0;m<=cap;m++)profiles[z][m].push_back(seq);
  }
  for(int m=0;m<=B(k);m++){auto &v=profiles[z][m];vector<vector<int>> keep;for(size_t i=0;i<v.size();i++){bool dominated=false;for(size_t j=0;j<v.size();j++)if(i!=j){bool ge=true,strict=false;for(int a=0;a<z;a++){if(v[j][a]<v[i][a])ge=false;if(v[j][a]>v[i][a])strict=true;}if(ge&&(strict||j<i)){dominated=true;break;}}if(!dominated)keep.push_back(v[i]);}v.swap(keep);}
 }
}
long long empty_correction(int D[64][64]){int v[16],z=0;long long sum=0;for(int i=0;i<k;i++)if(chosen[i]==0){int s=0;for(int p=0;p<=d;p++)s+=D[d+1+i][p];v[z++]=s;sum+=s;}if(!z)return 0;sort(v,v+z);long long upper=0;for(const auto &seq:*active_profiles){long long s=0;for(int i=0;i<z;i++)s+=min((long long)v[i],empty_upper[seq[i]]);upper=max(upper,s);}return sum-upper;}


void search_rows(vector<U>& adj,U rem,int cnt,int pos);
void choose_groups(vector<U>& adj,U rem,int cnt,int pos,const vector<vector<int>>& groups,int gi,int D[64][64],long long slack){
 if(slack<0){rowcuts++;return;}
 int a=d+1+pos;
 if(gi==(int)groups.size()){
   long long save=0; U ns=adj[a]>> (d+1); ns &= ~((1ULL<<(pos+1))-1);
   if(ns){ for(int j=0;j<=d;j++){
     int cap=D[a][j]; U t=ns;
     while(t){int b=d+1+__builtin_ctzll(t); t&=t-1;cap=min(cap,1+D[b][j]);save+=max(0,D[b][j]-1-D[a][j]);}
     save+=D[a][j]-cap;
   }}
   if(save>slack){rowcuts++;return;}
   search_rows(adj,rem,cnt,pos+1);return;
 }
 const auto& g=groups[gi]; int cost=0; for(int j:g)cost+=d-D[a][d+1+j];
 choose_groups(adj,rem,cnt,pos,groups,gi+1,D,slack-cost);
 for(int j:g){int b=d+1+j;adj[a]|=1ULL<<b;adj[b]|=1ULL<<a;cnt++;cost-=d-D[a][b];choose_groups(adj,rem,cnt,pos,groups,gi+1,D,slack-cost);}
 for(int j:g){int b=d+1+j;adj[a]&=~(1ULL<<b);adj[b]&=~(1ULL<<a);}
}
void search_rows(vector<U>& adj,U rem,int cnt,int pos){
 nodes++;int r=cnt-k;if(r>=A||r+__builtin_popcountll(rem)<=C)return;
 U all=(1ULL<<n)-1, seed=((1ULL<<(d+1))-1)|(all&~((1ULL<<(d+1+pos))-1)), reach=seed, frontier=seed;
 while(frontier){U next=0;while(frontier){int v=__builtin_ctzll(frontier);frontier&=frontier-1;next|=adj[v];}frontier=next&~reach;reach|=frontier;}if(reach!=all){pruned++;return;}
 int D[64][64];long long w;if(!dist(adj,D,w,false))return;if(!bound(r,rem,D,w-empty_correction(D))){pruned++;return;}if(pos<=2&&!pathbound(r,rem,D,w)){pruned++;return;}
 if(!rem){if(r>C&&w>=formula(r)){candidates++;long long ww;if(dist(adj,D,ww,true)){valid++;if(ww>best[r]){best[r]=ww;ties[r]=badties[r]=0;}if(ww==best[r]){ties[r]++;if(!shape(adj,r)){badties[r]++;ex[r]=adj;}}}}return;}
 if(!(rem&rowmask[pos])){search_rows(adj,rem,cnt,pos+1);return;}
 vector<vector<int>> groups;map<pair<int,U>,int> seen;
 for(int j=pos+1;j<k;j++)if(rem>>edgeindex[pos][j]&1){U hist=(adj[d+1+j]>>(d+1))&((1ULL<<pos)-1);auto key=make_pair(chosen[j],hist);auto it=seen.find(key);if(it==seen.end()){seen[key]=groups.size();groups.push_back({j});}else groups[it->second].push_back(j);}
 long long slack=w+1LL*(d-1)*r-target; U t=rem; while(t){int e=__builtin_ctzll(t);t&=t-1;auto [i,j]=ep[e];slack+=d-D[d+1+i][d+1+j];} choose_groups(adj,rem&~rowmask[pos],cnt,pos,groups,0,D,slack);
}
int md[100][64],pd[100][100],sm[100];
int refl[100]; long long reflectcut=0;
void test(int cnt){vector<int> mirror;for(int i:chosen)mirror.push_back(refl[i]);sort(mirror.begin(),mirror.end());if(chosen>mirror){reflectcut++;return;}masks++;U allowed=0;int D[64][64];long long w=1LL*d*(d+1)*(d+2)/6;
 for(int i=0;i<k;i++)w+=sm[chosen[i]];
 for(int z=0;z<(int)ep.size();z++){auto [i,j]=ep[z];U a=opts[chosen[i]],b=opts[chosen[j]];int dd=pd[chosen[i]][chosen[j]];D[d+1+i][d+1+j]=dd;w+=dd;if(!a||!b||(63-__builtin_clzll(a)-__builtin_ctzll(b)<=3&&63-__builtin_clzll(b)-__builtin_ctzll(a)<=3))allowed|=1ULL<<z;}
 int zc=count(chosen.begin(),chosen.end(),0);int minoff=max(0,C+1+k-cnt);active_profiles=&profiles[zc][minoff];if(active_profiles->empty()){pruned++;return;}profilemax=0;for(const auto &seq:*active_profiles){long long s=0;for(int h:seq)s+=empty_upper[h];profilemax=max(profilemax,s);}if(cnt+__builtin_popcountll(allowed)-k<=C||cnt-k>=A||!bound(cnt-k,allowed,D,w-1LL*zc*sm[0]+profilemax)){pruned++;return;}
 vector<U> adj(n);for(int j=0;j<d;j++){adj[j]|=1ULL<<(j+1);adj[j+1]|=1ULL<<j;}for(int i=0;i<k;i++){U m=opts[chosen[i]];adj[d+1+i]|=m;while(m){int j=__builtin_ctzll(m);m&=m-1;adj[j]|=1ULL<<(d+1+i);}}search_rows(adj,allowed,cnt,0);
}
// Prefix relaxation: W+(d-1)r is bounded by unary mask terms and d per pair.
long long suffix_unary[101];long long prefix_cut=0;
int compat[100][100], penalty[100][100]; int empty_count=0, zfilter=-1;
void rec(int pos,int low,int cnt,long long sum=0,int edges=0){
 int remaining=k-pos;
 if(zfilter>=0 && (empty_count>zfilter || (low>0 && empty_count!=zfilter) || empty_count+remaining<zfilter)){prefix_cut++;return;}
 // all empty masks are placed first. After the first nonempty mask, their number is fixed.
 if(low>0){if(sum+remaining* suffix_unary[low]+1LL*d*(d+1)*(d+2)/6+1LL*d*k*(k-1)/2-1LL*(d-1)*k-(1LL*empty_count*sm[0]-empty_sum[empty_count])<target){prefix_cut++;return;}}
 if(cnt+3*remaining+edges+remaining*pos+remaining*(remaining-1)/2-k<=C || cnt-k>=A){prefix_cut++;return;}
 long long mx=LLONG_MIN;
 for(int z=low;z<(int)opts.size();z++){
  long long val=sm[z]+1LL*(d-1)*__builtin_popcountll(opts[z]);
  for(int j=0;j<pos;j++)val-=penalty[z][chosen[j]];
  mx=max(mx,val);
 }
 if(sum+remaining*mx+1LL*d*(d+1)*(d+2)/6+1LL*d*k*(k-1)/2-1LL*(d-1)*k-(low>0?(1LL*empty_count*sm[0]-empty_sum[empty_count]):0)<target){prefix_cut++;return;}
 if(pos==k){test(cnt);return;}
 for(int z=low;z<(int)opts.size();z++){chosen[pos]=z;int p=__builtin_popcountll(opts[z]);long long v=sm[z]+1LL*(d-1)*p;int add=0;for(int j=0;j<pos;j++){v-=penalty[z][chosen[j]];add+=compat[z][chosen[j]];}empty_count+=(z==0);rec(pos+1,z,cnt+p,sum+v,edges+add);empty_count-=(z==0);}
}
int main(int argc,char**argv){k=atoi(argv[1]);d=atoi(argv[2]);if(argc>3)zfilter=atoi(argv[3]);n=d+1+k;assert(k<=10&&d<=20&&n<64);A=k*(k+1)/2;M=k*k/4;C=A-M;opts={0};for(int i=0;i<=d;i++)for(int j=0;j<4;j++){U m=(1ULL<<i)|(U(j)<<(i+1));if(m<(1ULL<<(d+1)))opts.push_back(m);}sort(opts.begin(),opts.end());opts.erase(unique(opts.begin(),opts.end()),opts.end());for(int i=0;i<(int)opts.size();i++){U m=0;for(int j=0;j<=d;j++)if(opts[i]>>j&1)m|=1ULL<<(d-j);refl[i]=lower_bound(opts.begin(),opts.end(),m)-opts.begin();}for(int i=0;i<k;i++)for(int j=i+1;j<k;j++){edgeindex[i][j]=ep.size();rowmask[i]|=1ULL<<ep.size();ep.emplace_back(i,j);}chosen.resize(k);best.resize(A+1,-1);ties.resize(A+1);badties.resize(A+1);ex.resize(A+1);for(int i=0;i<(int)opts.size();i++)for(int j=0;j<=d;j++){md[i][j]=d;for(int t=0;t<=d;t++)if(opts[i]>>t&1)md[i][j]=min(md[i][j],1+abs(t-j));sm[i]+=md[i][j];}for(int i=0;i<(int)opts.size();i++)for(int j=0;j<(int)opts.size();j++){pd[i][j]=d;for(int t=0;t<=d;t++)pd[i][j]=min(pd[i][j],md[i][t]+md[j][t]);}target=LLONG_MAX;for(int r=C+1;r<A;r++)target=min(target,formula(r)+1LL*(d-1)*r);for(int i=(int)opts.size()-1;i>=0;i--)suffix_unary[i]=max(suffix_unary[i+1],sm[i]+1LL*(d-1)*__builtin_popcountll(opts[i]));for(int i=0;i<(int)opts.size();i++)for(int j=0;j<(int)opts.size();j++){U a=opts[i],b=opts[j];compat[i][j]=!a||!b||(63-__builtin_clzll(a)-__builtin_ctzll(b)<=3&&63-__builtin_clzll(b)-__builtin_ctzll(a)<=3);penalty[i][j]=compat[i][j]?0:d-pd[i][j];}for(int z=1;z<=k;z++)for(int i=1;i<(int)opts.size();i++){long long val=0;for(int j=0;j<=d;j++)val+=min(d,z+md[i][j]);empty_upper[z]=max(empty_upper[z],val);}for(int z=1;z<=k;z++)empty_sum[z]=empty_sum[z-1]+empty_upper[z];make_profiles();rec(0,0,0);cout<<"k="<<k<<" d="<<d<<" zfilter="<<zfilter<<" options="<<opts.size()<<" prefix_cut="<<prefix_cut<<" masks="<<masks<<" nodes="<<nodes<<" pruned="<<pruned<<" reflectcut="<<reflectcut<<" rowcuts="<<rowcuts<<" exact_tests="<<candidates<<" valid="<<valid<<"\n";for(int r=C+1;r<A;r++){cout<<"r="<<r<<" best="<<best[r]<<" pred="<<formula(r)<<" ties="<<ties[r]<<" noncanonical="<<badties[r]<<"\n";if(badties[r]){cout<<"example ";for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)if(ex[r][i]>>j&1)cout<<i<<"-"<<j<<",";cout<<"\n";}}}
